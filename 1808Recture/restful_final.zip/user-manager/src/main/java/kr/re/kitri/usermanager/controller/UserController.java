package kr.re.kitri.usermanager.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import kr.re.kitri.usermanager.model.User;
import kr.re.kitri.usermanager.service.UserService;
import kr.re.kitri.usermanager.util.ApiResponse;
import kr.re.kitri.usermanager.util.ApiResponse.Status;

@RestController
@RequestMapping("/v1")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	// RestTemplate Get
	@GetMapping("rest/user/{userId}")
	public User testFindUserWithRestTemplate(@PathVariable String userId) {
		return restTemplate.getForObject("http://localhost:9090/v1/users/{userId}", 
				User.class, userId);
	}
	
	// RestTemplate Post
	@GetMapping("rest/users")
	public String registerUserWithRestTemplate() {
		User user = new User("11", "registerUserWithRestTemplate", 10);
		restTemplate.postForLocation("http://localhost:9090/v1/users", user);
		return "insert OK";
	}

	@GetMapping("/users")
//	public ResponseEntity<List<User>> viewUsers() {
	public ApiResponse viewUsers() {

		List<User> userList = userService.getAllUsers();

//		User user1 = new User("1", "kim", 10);
//		User user2 = new User("2", "lee", 20);
//		User user3 = new User("3", "kang", 30);
//		
//		List<User> userList = new ArrayList<User>();
//		userList.add(user1);
//		userList.add(user2);
//		userList.add(user3);

//		return new ResponseEntity<List<User>>(userList, HttpStatus.ACCEPTED);
//		return userList;
//		return new ResponseEntity<List<User>>(userList, HttpStatus.ACCEPTED);
//		return new ApiResponse(Status.ERROR, null, new ApiError(606, "DB연결오류"));
//		return new ApiResponse(Status.ERROR, null, new ApiResponse.ApiError(696, "db가 죽었어요"));
		
		return new ApiResponse(Status.OK, userList); 

	}

	@GetMapping("/users/{userId}")
//	public ResponseEntity<User> viewUserDetailByUserId(@PathVariable String userId) {
//	public ApiResponse viewUserDetailByUserId(@PathVariable String userId) {
	public User viewUserDetailByUserId(@PathVariable String userId) {
//		User user = new User(userId, "GetUserName", 22);
//		return new ResponseEntity<User>(user, HttpStatus.OK);
		
		User findedUser = userService.findUsersByUserId(userId);
//		return new ApiResponse(Status.OK, findedUser);
		return findedUser;
	}

	@PostMapping("/users")
	public ApiResponse registerUser(@RequestBody User user) {
		System.out.println(user);
		User registerUser = userService.registUser(user);
		return new ApiResponse(Status.OK, registerUser);
//		 User user = new User(userId, "GetUserName", 22);
//		 return new ResponseEntity<User>(user, HttpStatus.OK);
	}

	// TO-DO @PostMapping("/users")

	@PutMapping("/users")
//	public ResponseEntity<User> modifyUserInfo(@RequestParam String userId, @RequestParam String userName, @RequestParam int age) {
	public ResponseEntity<User> modifyUserInfo(@RequestBody User user) {
		// TO-DO userId를 받아서 로그로 출력
//		System.out.println("userId: " + userId);
//		return new ResponseEntity<User>(new User(userId, userName, age), HttpStatus.OK);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}

	@DeleteMapping("/users/{userId}")
	public ApiResponse removeUser(@PathVariable String userId) {
		return new ApiResponse(Status.OK, "remove OK");
	}
}

package kr.re.kitri.usermanager.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.re.kitri.usermanager.dao.UserDao;
import kr.re.kitri.usermanager.model.User;

@Service
public class UserService {

	@Autowired
	private UserDao userDao;
	
	// Show All
	public List<User> getAllUsers() {
//		User user1 = new User("1", "kim", 10);
//		User user2 = new User("2", "lee", 20);
//		User user3 = new User("3", "kang", 30);
//		
//		List<User> userList = new ArrayList<User>();
//		userList.add(user1);
//		userList.add(user2);
//		userList.add(user3);

		List<User> userList = userDao.selectAllUsers();
		
		return userList;
	}
	
	// Regist User
	public User registUser(User user) {
		User insertedUser = userDao.insertUser(user);
		return insertedUser;
	}

	public User findUsersByUserId(String userId) {
		return userDao.selectUserByKey(userId);
	}
}

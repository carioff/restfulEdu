package kr.re.kitri.usermanager.exception;

import org.h2.jdbc.JdbcSQLException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import kr.re.kitri.usermanager.util.ApiResponse;
import kr.re.kitri.usermanager.util.ApiResponse.Status;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler {

	@ExceptionHandler(value = JdbcSQLException.class)
	public ApiResponse handleSQLException(JdbcSQLException e) {
		return new ApiResponse(Status.ERROR, 
				null, 
//				new ApiResponse.ApiError(500, e.getMessage()));
				new ApiResponse.ApiError(500, "중복된 사용자입니다. 다시 등록해주세요."));
	}
	
	//EmptyResultDataAccessException
	@ExceptionHandler(value = EmptyResultDataAccessException.class)
	public ApiResponse handleEmptyResultDataAccessException(EmptyResultDataAccessException e) {
		return new ApiResponse(Status.ERROR, 
				null, 
//				new ApiResponse.ApiError(500, e.getMessage()));
				new ApiResponse.ApiError(600, "검색된 사용자가 없습니다. 다른 userId로 검색해주세요."));
	}
}

package kr.re.kitri.usermanager.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import kr.re.kitri.usermanager.model.User;

@Repository
public class UserDao {

	private static final Logger logger = LoggerFactory.getLogger(UserDao.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	// Insert User
	public User insertUser(User user) {
		int updated = jdbcTemplate.update("INSERT INTO USER VALUES(?, ?, ?)"
				, user.getUserId(), user.getUserName(), user.getAge());
		if(updated > 0) {
			logger.debug("before insertUser");
			return user;
		} else {
			return null;
		}
	}
	
	public List<User> selectAllUsers() {
//		User user1 = new User("1", "kimchulseung", 10);
//		User user2 = new User("2", "lee", 20);
//		User user3 = new User("3", "kang", 30);
//		
//		List<User> userList = new ArrayList<User>();
//		userList.add(user1);
//		userList.add(user2);
//		userList.add(user3);
		List<User> userList = jdbcTemplate.query("SELECT USER_ID, USER_NAME, AGE FROM USER USER", 
				new BeanPropertyRowMapper<User>(User.class));
		
		return userList;
	}

	public User selectUserByKey(String userId) {
		return jdbcTemplate.queryForObject("SELECT USER_ID, USER_NAME, AGE FROM USER USER WHERE USER_ID = ?", 
				new Object[] {userId}, 
				new BeanPropertyRowMapper<>(User.class));
		
	}


}
